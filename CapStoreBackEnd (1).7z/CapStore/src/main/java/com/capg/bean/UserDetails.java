package com.capg.bean;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class UserDetails {
	@Id
	private int cvv;
	
	private int balance;

	public UserDetails() {
		super();

	}

	public UserDetails(int cvv, int balance) {
		super();
		this.cvv = cvv;
		this.balance = balance;
	}

	public int getCvv() {
		return cvv;
	}

	public void setCvv(int cvv) {
		this.cvv = cvv;
	}

	public int getBalance() {
		return balance;
	}

	public void setBalance(int balance) {
		this.balance = balance;
	}

}
