package com.capg.bean;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class CapStore {
	@Id
	private long accNo;
	private double balance;

	public CapStore() {
		super();
	}

	public CapStore(long accNo, double balance) {
		super();
		this.accNo = accNo;
		this.balance = balance;
	}

	public long getAccNo() {
		return accNo;
	}

	public void setAccNo(long accNo) {
		this.accNo = accNo;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}
}