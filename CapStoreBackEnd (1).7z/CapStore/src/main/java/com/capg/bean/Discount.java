package com.capg.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;

@Entity

@Table(name = "Discount_Capg")
public class Discount {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "id", updatable = false, nullable = false)
	private int id;
	@Min(0000)
	@Max(40000)

	private double price;

	private String discountStatement;

	private float finalPrice;

	/**
	 * 
	 */
	public Discount() {
		super();
	}

	/**
	 * @param id
	 * @param price
	 * @param discountStatement
	 * @param finalPrice
	 */
	public Discount(int id, float price, String discountStatement, float finalPrice) {
		super();
		this.id = id;
		this.price = price;
		this.discountStatement = discountStatement;
		this.finalPrice = finalPrice;
	}

	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * @return the price
	 */
	public double getPrice() {
		return price;
	}

	/**
	 * @param price
	 *            the price to set
	 */
	public void setPrice(double price) {
		this.price = price;
	}

	/**
	 * @return the discount
	 */
	public String getdiscountStatement() {
		return discountStatement;
	}

	/**
	 * @param discount
	 *            the discount to set
	 */
	public void setdiscountStatement(String discountStatement) {
		this.discountStatement = discountStatement;
	}

	/**
	 * @return the finalPrice
	 */
	public float getFinalPrice() {
		return finalPrice;
	}

	/**
	 * @param finalPrice
	 *            the finalPrice to set
	 */
	public void setFinalPrice(float finalPrice) {
		this.finalPrice = finalPrice;
	}

	@Override
	public String toString() {
		return "Discount [id=" + id + ", price=" + price + ", discountStatement=" + discountStatement + ", finalPrice="
				+ finalPrice + "]";
	}

}
