package com.capg.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.Pattern;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

@Entity
@Table(name = "TR5ThirdPartyMerchant")
public class ThirdPartyMerchant {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "credential_seq")
	@GenericGenerator(

			name = "credential_seq",

			strategy = "com.capg.bean.StringPrefixedSequenceIdGenerator",

			parameters = {

					@Parameter(name = StringPrefixedSequenceIdGenerator.INCREMENT_PARAM, value = "1"),

					@Parameter(name = StringPrefixedSequenceIdGenerator.VALUE_PREFIX_PARAMETER, value = "MERC_"),

					@Parameter(name = StringPrefixedSequenceIdGenerator.NUMBER_FORMAT_PARAMETER, value = "%05d") })

	private String tpId;
	private String tpName;
	@Email
	private String emailId;
	@Pattern(regexp = "(true|false)")
	private String isJoined;

	public String getTpId() {
		return tpId;
	}

	public void setTpId(String tpId) {
		this.tpId = tpId;
	}

	public String getTpName() {
		return tpName;
	}

	public void setTpName(String tpName) {
		this.tpName = tpName;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getIsJoined() {
		return isJoined;
	}

	public void setIsJoined(String isJoined) {
		this.isJoined = isJoined;
	}

	@Override
	public String toString() {
		return "ThirdPartyMerchant [tpId=" + tpId + ", tpName=" + tpName + ", emailId=" + emailId + ", isJoined="
				+ isJoined + "]";
	}

}
