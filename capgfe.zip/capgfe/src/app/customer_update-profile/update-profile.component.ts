import { Component, OnInit } from '@angular/core';
import { DashboardServiceService } from '../dashboard-service.service';
import { Customer } from '../Customer';

@Component({
  selector: 'app-update-profile',
  templateUrl: './update-profile.component.html',
  styleUrls: ['./update-profile.component.css']
})
export class UpdateProfileComponent implements OnInit {
  customer: Customer;

  constructor(private dashboardService: DashboardServiceService) { }

  ngOnInit() {

  }
  saveAttributes(oldpassword: string,newpassword: string,confirm: string){
    this.customer= new Customer()
    
    this.customer.oldpassword=oldpassword;
    this.customer.newpassword=newpassword;
    this.customer.confirm=confirm;
    this.dashboardService.setProfileAttributes(this.customer).subscribe(data=>{
      alert("Profile updated")
    });
  }

  


}
