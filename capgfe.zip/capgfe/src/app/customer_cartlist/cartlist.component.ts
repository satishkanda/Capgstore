import { Component, OnInit } from '@angular/core';
import { DashboardServiceService } from '../dashboard-service.service';
import { Cartlist } from '../cartlist';
import { Router } from '@angular/router';
import { IProductDetails } from '../iproduct-details';
import { CapstoreService } from '../capstore.service';
import { CapStoreService } from '../cap-store.service';
import { Product } from '../Product';

@Component({
  selector: 'app-cartlist',
  templateUrl: './cartlist.component.html',
  styleUrls: ['./cartlist.component.css']
})
export class CartlistComponent implements OnInit {
pro:IProductDetails[];
  router: Router;
  ser:CapStoreService;
  constructor(private service:DashboardServiceService,ser:CapStoreService,  router: Router) {
    this.router = router;
    this.ser=ser;
   }

  cartlist:Cartlist[];
  ngOnInit() {
    // this.service.getCartProducts().subscribe(data => {
    //   this.cartlist = data;
    //   console.log(this.cartlist);
    //   });
    this.pro=this.ser.getcart();
    
  }
  deleteFromCart(cart) {
    let index=this.pro.indexOf(cart);
    this.pro.splice(index,1);
    alert("deleted Successful!!");
  //   if (confirm("Are you Sure to REMOVE??")) {
  //   this.service.deleteFromCart(cartId).subscribe(data => {
  //   this.cartlist = data;
  //   });
  //   this.router.navigateByUrl('/dashboardc');
  //   }
  //   }

  //   total=0;
  //   qty=0;
  //   placeOrder(data){
  //     console.log(data);
  //    for(let i =0 ; i< this.cartlist.length ; i++){
  //      console.log(this.cartlist[i].cartProduct.price);
  //      console.log(data.orderQty);
  //      this.total = this.cartlist[i].cartProduct.price*data.orderQty;
       
  //   }
  //  // this.router.navigateByUrl('/orderedItemDetails');
  // }
  }

//   total=0;
//  placeOrder(data){
 
//  for(let i =0 ; i< this.cartlist.length ; i++){
//  if(data.ordrQty < 50) {
//  // this.total = this.cartlist[i].cartProduct.price*data.orderQty;
//  // this.capStoreService.updateInventory(data.orderQty,this.cartlist[i].cartProduct.prodId);
//  this.router.navigateByUrl('/orderedItemDetails');
//  } 
//  else {
//  alert("Can't place order.\nOrder quantity greater than available quantity");
//  }

//  }
//  }

}
