import { Component, OnInit } from '@angular/core';

import { CapStoreService } from '../cap-store.service';
import { IProductDetails } from '../iproduct-details';
// import { OrderedItem } from '../OrderedItem';


@Component({
  selector: 'app-voice',
  templateUrl: './voice.component.html',
  styleUrls: ['./voice.component.css']
})
export class VoiceComponent implements OnInit {

  product: IProductDetails[]=[];

 // dataList: OrderedItem;
  constructor(private service:CapStoreService) { }

  ngOnInit() {
   
    this.product = this.service.getcart();
    console.log(this.product);
//   // let orderId=this.service.getOrderTransaction().ordItem.ordId;
//    // this.service.showorder(orderId).subscribe(data=>{
//       if(data==null)
//       {
//         console.error("Problem Generating Invoice");
        
//       }
//       else{
//         this.dataList=data;
//       }
//     });
//   }
// }
  }
  return(){
    alert("Returned Successfully!!");
  }
}