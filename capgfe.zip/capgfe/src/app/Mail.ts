export class Email{
    fromMailId:string;
    toMailId:string;
    mail:string;
   constructor(){}
   
} 